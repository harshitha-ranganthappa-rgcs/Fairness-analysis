import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report, confusion_matrix
import fairlearn
from fairlearn.metrics import MetricFrame, selection_rate, count
from fairlearn.reductions import DemographicParity, ExponentiatedGradient
import matplotlib.pyplot as plt
import seaborn as sns

def load_and_preprocess_data(filepath, sensitive_feature):
    """Loads and preprocesses the dataset."""
    try:
        data = pd.read_csv(filepath)
    except FileNotFoundError:
        raise FileNotFoundError(f"File not found at {filepath}")

    # Basic handling of missing values (replace with mean for simplicity, more robust methods are needed in real-world scenarios)
    for col in data.columns:
        if data[col].isnull().any():
            if pd.api.types.is_numeric_dtype(data[col]):
                data[col].fillna(data[col].mean(), inplace=True)
            else:
                data[col].fillna(data[col].mode()[0], inplace=True)

    # Separate features and target
    y = data['target_column']  # Replace 'target_column'
    X = data.drop('target_column', axis=1)

    # Separate sensitive feature
    sensitive_features = X[sensitive_feature]
    X = X.drop(sensitive_feature, axis=1)

    # Scale numerical features
    numerical_features = X.select_dtypes(include=np.number).columns
    scaler = StandardScaler()
    X[numerical_features] = scaler.fit_transform(X[numerical_features])

    X_train, X_test, y_train, y_test, sensitive_features_train, sensitive_features_test = train_test_split(
        X, y, sensitive_features, test_size=0.2, random_state=42
    )

    return X_train, X_test, y_train, y_test, sensitive_features_train, sensitive_features_test

def train_and_evaluate(X_train, X_test, y_train, y_test, sensitive_features_test, sensitive_feature):
    """Trains a model and evaluates its performance and fairness."""

    # Train a standard model
    model = LogisticRegression(solver='liblinear', random_state=42)
    model.fit(X_train, y_train)
    y_pred = model.predict(X_test)

    # Evaluate standard model
    print("Standard Model Evaluation:")
    print(classification_report(y_test, y_pred))
    print(confusion_matrix(y_test, y_pred))

    # Fairness evaluation
    metric_frame = MetricFrame(metrics={"selection_rate": selection_rate, "count": count},
                               y_true=y_test,
                               y_pred=y_pred,
                               sensitive_features=sensitive_features_test)

    print("\nFairness Metrics (Standard Model):")
    print(metric_frame.overall)
    print(metric_frame.by_group)

    # Visualize fairness metrics (example: selection rate)
    plt.figure(figsize=(8, 6))
    sns.barplot(x=metric_frame.by_group.index, y=metric_frame.by_group['selection_rate'])
    plt.title(f"Selection Rate by {sensitive_feature}")
    plt.xlabel(sensitive_feature)
    plt.ylabel("Selection Rate")
    plt.show()

    return model

def mitigate_bias(X_train, y_train, sensitive_features_train, X_test, y_test, sensitive_features_test, sensitive_feature):
    """Mitigates bias using Fairlearn's Exponentiated Gradient algorithm."""

    estimator = LogisticRegression(solver='liblinear', fit_intercept=True)
    constraint = DemographicParity()
    mitigated_model = ExponentiatedGradient(estimator, constraint)
    mitigated_model.fit(X_train, y_train, sensitive_features=sensitive_features_train)
    mitigated_y_pred = mitigated_model.predict(X_test)

    print("\nMitigated Model Evaluation:")
    print(classification_report(y_test, mitigated_y_pred))
    print(confusion_matrix(y_test, mitigated_y_pred))

    # Fairness evaluation of mitigated model
    mitigated_metric_frame = MetricFrame(metrics={"selection_rate": selection_rate, "count": count},
                               y_true=y_test,
                               y_pred=mitigated_y_pred,
                               sensitive_features=sensitive_features_test)

    print("\nFairness Metrics (Mitigated Model):")
    print(mitigated_metric_frame.overall)
    print(mitigated_metric_frame.by_group)

    # Visualize fairness metrics (example: selection rate)
    plt.figure(figsize=(8, 6))
    sns.barplot(x=mitigated_metric_frame.by_group.index, y=mitigated_metric_frame.by_group['selection_rate'])
    plt.title(f"Mitigated Selection Rate by {sensitive_feature}")
    plt.xlabel(sensitive_feature)
    plt.ylabel("Selection Rate")
    plt.show()

def main(filepath, sensitive_feature):
    """Main function to orchestrate data loading, training, and bias mitigation."""
    try:
        X_train, X_test, y_train, y_test, sensitive_features_train, sensitive_features_test = load_and_preprocess_data(filepath, sensitive_feature)
        standard_model = train_and_evaluate(X_train, X_test, y_train, y_test, sensitive_features_test, sensitive_feature)
        mitigate_bias(X_train, y_train, sensitive_features_train, X_test, y_test, sensitive_features_test, sensitive_feature)
    except FileNotFoundError as e:
        print(e)
    except KeyError as e:
        print(f"KeyError: {e}. Ensure 'target_column' and '{sensitive_feature}' are correct column names.")
    except Exception as e:
        print(f"An unexpected error occurred: {e}")

if __name__ == "__main__":
    filepath = "data/data.csv" # Place your data.csv file into a data folder.
    sensitive_feature = "sensitive_feature" # Replace with your sensitive feature column name
    main(filepath, sensitive_feature)